import java.util.Scanner;
import javax.swing.*;
public class Principal_Circulo {
    public static void main(String[] args)
    {
     Scanner bryan=new Scanner(System.in);
    
          float radio=Float.parseFloat(JOptionPane.showInputDialog(null,"Inserte el Radio "));
        
       circulo br=new circulo();
       br.area(radio);
       br.perimetro(radio);
       br.diametro(radio);
    }
}
