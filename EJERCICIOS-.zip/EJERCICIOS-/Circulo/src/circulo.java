/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 8VV50LA_2004
 */
public class circulo
        
{
   public void area(float radio) 
   {
       float area;
       area = (float) (Math.PI*Math.pow(radio, 2));
       System.out.println("El area del circulo es: " + area);  
   }
   public void perimetro(float radio)
   {
       float per;
       per= (float) (2*Math.PI* radio);
       System.out.println("El perimetro es: " + per);
       
   }
   public void diametro(float radio)
  {
          float diam;
          diam= 2*radio;
          System.out.println("El diametro es: " + diam);
        
   }
           
}
