

/**
 *
 * @author Bryan Valerio Reyes 
 */
public class persona {
 
    private String nombre;
    private String direccion;
    private String telefono;
    private String correo;


    public persona(){
        
      nombre="";
      direccion="";
      telefono="";
      correo="";
      
}
    public persona(String nombre,String direccion, String telefono, String correo){
        this.nombre=nombre;
        this.direccion=direccion;
        this.telefono=telefono;
        this.correo=correo;
    }
    
    
    
    public void setnombre(String nombre){
        this.nombre=nombre;
    }
    
    public String getnombre(){
        return nombre;
    }
    
     public void setdireccion(String direccion){
        this.direccion=direccion;
    }
    
    public String getdireccion(){
        return direccion;
    }
    
     public void settelefono(String telefono ){
        this.telefono=telefono;
    }
    
    public String gettelefono(){
        return telefono ;
    }
    
      public void setcorreo(String correo ){
        this.correo=correo;
    }
    
    public String getcorreo (){
        return correo;
    }
    
    
       @Override
  public String toString(){
        return "Nombre : " +getnombre()+"\n"
                +"direccion: "+getdireccion()+"\n"
                +"telefono"+ gettelefono()+"\n"
                +"correo: "+getcorreo();
    }
    
    
    
    
    
    
    
    
}
   

 














