
import java.util.Scanner;


/**
 *
 * @author Bryan Valerio Reyes
 */
public class principalmain {
    
    public static void main (String[]arg){
         Scanner leer= new Scanner(System.in);
         
        persona array[]=new persona[2];
        
        String nombre ="";
        String direccion ="";
        String telefono="";
        String correo ="";
        
        
        
      for( int i=0;i<array.length;i++){
          
          System.out.println("ingresa tu nombre");
          nombre=leer.nextLine();
          
          System.out.println("ingresa tu direccion");
          direccion=leer.nextLine();
          
          System.out.println("ingresa tu telefono");
         telefono=leer.nextLine();
          
          System.out.println("ingresa tu correo");
          correo=leer.nextLine();
          
          leer.nextLine();
          
          
          array[i]=new persona(nombre,direccion,telefono,correo);
      
      }
      for( int i=0;i<array.length;i++){
          
          System.out.println(array[i].toString());
          
           System.out.println("");
            System.out.println("");
            System.out.println("");
             System.out.println("");
           
      
            
      }
      
      
      
      
           
      
      
      
    
}
}
