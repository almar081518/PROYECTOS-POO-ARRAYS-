
package operaciones.basicas;

public class Operaciones {
    private double a=0;
    private double b=0;
    private double r1=0;
    
    public void setA(double a)
    {
      this.a=a;  
    }
    public double getA()
    {
        return a;
    }
    
    public void setB(double b)
    {
      this.b=b;  
    }
    public double getB()
    {
        return b;
    }
   
       public void setR1(double r1)
    {
      this.r1=r1;  
    }
    public double getR1()
    {
        return r1;
    }
    public void sumaa(double getA, double getB)
    {
        this.r1=this.a+this.b;
       System.out.println("Su suma es: " + this.r1);
        
    }
    public void restaa(double getA, double getB)
    {
        this.r1=this.a-this.b;
       System.out.println("Su resta es: " + this.r1);
    }
    public void producto(double getA, double getB)
    {
        this.r1=this.a*this.b;
       System.out.println("La multiplicacion es: " + this.r1);
    }
    public void division(double getA, double getB)
    {
        this.r1=this.a/this.b;
       System.out.println("Su division es: " + this.r1);
       
    }
 
}