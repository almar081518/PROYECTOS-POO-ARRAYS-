
package operaciones.basicas;
import java.util.Scanner;
import javax.swing.*;

public class OperacionesBasicas 
{
    public static void main(String[] args)
    {
       Scanner sc=new Scanner(System.in);
      
        Operaciones sum=new Operaciones();
        
        sum.setA(Double.parseDouble(JOptionPane.showInputDialog(null,"Ingrese el primer numero para sumar ")));
        sum.setB(Double.parseDouble(JOptionPane.showInputDialog(null,"Ingrese el segundo numero")));
        sum.sumaa(sum.getA(), sum.getB());
       
        Operaciones res= new Operaciones();
        res.setA(Double.parseDouble(JOptionPane.showInputDialog(null,"Ingrese el primer numero para restar")));
        res.setB(Double.parseDouble(JOptionPane.showInputDialog(null,"Ingreseel segundo numero")));
        res.restaa(res.getA(), res.getB());
        
        Operaciones div= new Operaciones();
        div.setA(Double.parseDouble(JOptionPane.showInputDialog(null,"Ingrese el primer numero para dividir")));
        div.setB(Double.parseDouble(JOptionPane.showInputDialog(null,"Ingrese el segundo numero")));
        div.division(div.getA(), div.getB());
        
        Operaciones pr= new Operaciones();
        pr.setA( Double.parseDouble(JOptionPane.showInputDialog(null,"Ingrese el primer numero para multiplicar")));
        pr.setB(Double.parseDouble(JOptionPane.showInputDialog(null,"Ingrese el segundo numero")));
        pr.producto(pr.getA(), pr.getB());
    } 
    
}
