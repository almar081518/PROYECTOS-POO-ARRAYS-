
import java.util.Scanner;

/**
 *
 * @author Christian-Reyes
 */
public class Main {
    public static void main(String[] args) {
        int r,i;
        String nombre;
        int cuenta,interes,numeroCuentas;
        float saldo,ingreso,retiro;
        Scanner leer = new Scanner(System.in);
        
        System.out.print("Digite la cantidad de Cuentas: ");
        numeroCuentas = leer.nextInt();
        
        //creamos los objetos para los coches
        CCuenta cuentas[] = new CCuenta[numeroCuentas];
        
        for(int j=0;j<cuentas.length;j++){
            System.out.print("-----BIENVENIDO-----\n");
            leer.nextLine();
            System.out.println("Ingrese el nombre del propietario de la cuenta "+(j+1)+": ");
            nombre=leer.nextLine();
            System.out.println("Ingrese el numero de la cuenta "+(j+1)+": ");
            cuenta=leer.nextInt();
            System.out.println("Ingrese el Saldo actual de su cuenta "+(j+1)+": ");
            saldo=leer.nextFloat();
            System.out.println("Ingrese el tipo de interés de la cuenta "+(j+1)+": ");
            interes=leer.nextInt();
            cuentas[j]=new CCuenta(nombre,cuenta,saldo,interes);
//            cuentas[j]=new CCuenta();
//            cuentas[j].setNombre(nombre);
//            cuentas[j].setCuenta(cuenta);
//            cuentas[j].setSaldo(saldo);
//            cuentas[j].setInteres(interes);
            
            for (int s=0;s!=1;s++){
                System.out.println("Desea realizar un Deposito: 1=si / 0=no ");
                r=leer.nextInt();
                while(r==1){
                    System.out.println("Monto a Depositar: ");
                    ingreso=leer.nextFloat();
                    cuentas[j].realizarIngreso(ingreso);
                    System.out.println("Desea realizar un nuevo Deposito: 1=si / 0=no ");
                    r=leer.nextInt();
                }

                System.out.println("Desea realizar un Retiro: 1=si / 0=no ");
                r=leer.nextInt();
                while(r==1){
                    System.out.println("Monto a Retirar: ");
                    retiro=leer.nextFloat();
                    cuentas[j].realizarRetiro(retiro);
                    System.out.println("Desea realizar un nuevo Retiro: 1=si / 0=no ");
                    r=leer.nextInt();
                }

                System.out.println("Desea Finalizar: 1=si / 0=no ");
                s=leer.nextInt();
                s -= 1;
            }
//            System.out.println(cuentas[j].toString());
//            System.out.println("");
//            System.out.println("");
//            System.out.println("");
        }
        System.out.println("_____GRACIAS, VUELVA PRONTO :)_____");
        
        for(int n=0;n<cuentas.length;n++){
            System.out.println(cuentas[n].toString());
//            System.out.println("Nombre del titular: "+cuentas[n].getNombre());
//            System.out.println("Número de cuenta: "+cuentas[n].getCuenta());
//            System.out.println("Saldo de la cuenta: "+cuentas[n].getSaldo());
//            System.out.println("Tipo de interes: "+cuentas[n].getInteres());
            System.out.println("");
            System.out.println("");
            System.out.println("");
        }
    }
}
