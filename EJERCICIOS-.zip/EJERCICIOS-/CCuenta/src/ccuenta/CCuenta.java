

/**
 *
 * @author Christian-Reyes
 */
public class CCuenta {
    private String nombre;
    private int cuenta;
    private float saldo;
    private int interes;
    
    public CCuenta(String nombre, int cuenta, float saldo, int interes){
        this.nombre=nombre;
        this.cuenta=cuenta;
        this.saldo=saldo;
        this.interes=interes;
    }

    public CCuenta() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCuenta() {
        return cuenta;
    }

    public void setCuenta(int cuenta) {
        this.cuenta = cuenta;
    }
    
    public float getSaldo(){
        return saldo;
    }
    
    public void setSaldo(float saldo){
        this.saldo=saldo;
    }

    public float getInteres() {
        return interes;
    }

    public void setInteres(int interes) {
        this.interes = interes;
    }
    
    
    public void realizarIngreso(float ingreso){
        saldo+=ingreso;
    }
    
    public void realizarRetiro(float retiro){
        saldo=saldo-retiro;
    } 
    @Override
    public String toString(){
        return "Nombre del titular: "+getNombre()+"\n"
                +"Numero de Cuenta: "+getCuenta()+"\n"
                +"Interés: %"+getInteres()+"\n"
                +"Saldo Actual: "+getSaldo();
    }
}